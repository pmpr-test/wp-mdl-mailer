<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             681fcb52a2945             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Email; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Mailer\AbstractEmail; class Test extends AbstractEmail { const sqassuyceueioiac = 'send_to'; public function qiccuiwooiquycsg() { $this->usuqmwksoeaayaig('test_email')->gswweykyogmsyawy(__('Test Email', PR__MDL__MAILER))->saemoowcasogykak(IconInterface::ckqqkkgqwgmckeao)->gucwmccyimoagwcm(__('Configure Test', PR__MDL__MAILER)); } public function oiakkwmiymaqusso() : array { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); return [$uuyucgkyusckoaeq->ymuegqgyuagyucws(self::sqassuyceueioiac)->mkiaygiogeeyogqm()->gswweykyogmsyawy(__('Send To', PR__MDL__MAILER))->cuomeiwckekemywm(__('After completing the general section fields, save the settings, then you can send a test email.', PR__MDL__MAILER), Constants::smkwuwawwaqyimcq)->ioumayywwckwmykk($uuyucgkyusckoaeq->qoeiescseggagsqs('send_email')->gswweykyogmsyawy(__('Send Email', PR__MDL__MAILER))->ygagwkucacyassau()->gmscmskmuissgywk()->ckccqugcgucieugo())]; } }
