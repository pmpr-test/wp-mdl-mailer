<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec208b16f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Mailer\Setting\Setting; abstract class Container extends BaseClass { const yckkaiueuoiicisc = "\141\x75\164\150\157\x72\151\172\x65\x64"; const oiugqmossekuqeia = "\157\x61\x75\x74\150\x5f\x67\162\141\x6e\x74"; const ewmyoqeiikakqqmk = "\x61\165\x74\x68\x6f\x72\x69\x7a\141\x74\x69\157\x6e\x5f\x75\x72\151"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
