<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             683729f5ba23b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
