<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e79fa2eb4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Generic; class Generic extends Common { public function mameiwsayuyquoeq() { if (!("\147\x65\x6e\x65\x72\x69\143" === Setting::symcgieuakksimmu()->guseqygmqcgeyigi())) { goto igymseewwyiocoug; } Engine::symcgieuakksimmu(); igymseewwyiocoug: } }
