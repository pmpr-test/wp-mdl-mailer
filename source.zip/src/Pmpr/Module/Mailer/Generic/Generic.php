<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec208b16f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Generic; class Generic extends Common { public function mameiwsayuyquoeq() { if (!("\147\x65\x6e\145\x72\151\143" === Setting::symcgieuakksimmu()->guseqygmqcgeyigi())) { goto igymseewwyiocoug; } Engine::symcgieuakksimmu(); igymseewwyiocoug: } }
