<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae89ce2e09             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Generic; class Generic extends Common { public function mameiwsayuyquoeq() { if (!("\x67\145\x6e\145\162\x69\x63" === Setting::symcgieuakksimmu()->guseqygmqcgeyigi())) { goto igymseewwyiocoug; } Engine::symcgieuakksimmu(); igymseewwyiocoug: } }
